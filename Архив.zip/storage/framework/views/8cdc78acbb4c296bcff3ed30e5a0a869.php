<?php $__env->startSection('title', 'Download ' . $file->original_name . ' from SendSpace'); ?>
<?php $__env->startSection('body_id', '_page'); ?>

<?php $__env->startSection('meta_description', ($file->description ?: 'Скачать файл ' . $file->original_name . ' (' . $file->formatted_size . ') с SendSpace')); ?>
<?php $__env->startSection('og_title', $file->original_name . ' (' . $file->formatted_size . ') — SendSpace'); ?>
<?php $__env->startSection('canonical_url', url('/file/' . $file->download_token)); ?>
<?php $__env->startSection('og_type', 'article'); ?>

<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header_content'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
  <div class="centered limit-width">
    <div id="headline">
      <h1 class="droid">Download</h1>
      <div class="actions file">
        <a href="/" class="button upload_new_file">&gt; Upload New File</a>
      </div>
    </div>

    <div class="clear"></div>
    <div id="content" class="download_with_ads">
      <div class="info">
        <div style="padding-top:10px;min-height:320px">
          <div style="padding:0;margin:0 10px;width:520px">

            <div style="display: table; width:100%;">
              <h2 class="bgray" style="display: table-cell;"><b><?php echo e($file->original_name); ?></b></h2>
            </div>

            <div class="file_description reverse margin_center">
              <b>File Size:</b> <?php echo e($file->formatted_size); ?>

            </div>

            <?php if($file->description): ?>
              <p><b>Description:</b> <?php echo e($file->description); ?></p>
            <?php endif; ?>

            <br>
            <div class="text dlact_wrap">
              <div id="spndllink">
                <div class="dlfile_actions" role="main">
                  <a id="download_button" class="download_page_button button1"
                    href="<?php echo e(route('file.download', $file->download_token)); ?>"
                    title="Click here to download, <?php echo e($file->original_name); ?>"
                    tabindex="0" accesskey="l" role="button">Download</a>
                </div>
                <br>
              </div>
            </div>

          </div>
        </div>
        <div class="clear"></div>
      </div>
      <div class="clear"></div>
    </div>

    <noscript>
      <div id="nojs" style='border: 1px solid #F7941D; background: #FEEFDA; text-align: center; clear: both; height: 75px; position: relative;'>
        <div style='width: 640px; margin: 0 auto; text-align: left; padding: 0; overflow: hidden; color: black;'>
          <div style='width: 100%; float: left; font-family: Arial, sans-serif;'>
            <div style='width: 75px; float: left;'><img src='/graphics/ie6nomore/ie6nomore-warning.jpg' alt="Warning!" /></div>
            <div style='font-size: 14px; font-weight: bold; margin-top: 12px;'>No javascript available!</div>
            <div style='font-size: 12px; margin-top: 6px; line-height: 12px;'>Your browser does not support JavaScript or JavaScript is disabled.</div>
          </div>
        </div>
      </div>
    </noscript>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/danil/Downloads/sendspace/sendspace/resources/views/download.blade.php ENDPATH**/ ?>